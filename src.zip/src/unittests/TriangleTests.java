/**
 * 
 */
package unittests;

import static org.junit.jupiter.api.Assertions.*;
import geometries.Triangle;
import primitives.*;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for geometries.Triangle class
 */
class TriangleTests {

	/**
     * Test method for {@link geometries.Triangle#getNormal(primitives.Point)}.
     */
    @Test
    void testGetNormal() {
        // ============ Equivalence Partitions Tests ==============

        // יצירת שלוש נקודות שאינן על קו ישר
        Point p1 = new Point(0, 0, 1);
        Point p2 = new Point(1, 0, 0);
        Point p3 = new Point(0, 1, 0);

        // יצירת המשולש
        Triangle triangle = new Triangle(p1, p2, p3);

        // בדיקת הנורמל
        Vector normal = triangle.getNormal(p1);

        // TC01: הנורמל לא null
        assertNotNull(normal, "getNormal() returned null");

        // TC02: אורך הנורמל צריך להיות 1
        assertEquals(1, normal.length(), 0.00001, "Normal vector is not unit length");

        // TC03: הנורמל צריך להיות מאונך לשני וקטורים על פני המשולש
        Vector v1 = p2.subtract(p1);
        Vector v2 = p3.subtract(p1);
        assertEquals(0, normal.dotProduct(v1), 0.00001, "Normal is not orthogonal to vector1");
        assertEquals(0, normal.dotProduct(v2), 0.00001, "Normal is not orthogonal to vector2");
    }

}
