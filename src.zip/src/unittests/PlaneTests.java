package unittests;

import geometries.Plane;
import primitives.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 * Unit tests for geometries.Plane class
 * @author Ahuva Winkler
 */
class PlaneTests {

    /**
     * Test method for {@link geometries.Plane#getNormal(primitives.Point)}.
     */
    @Test
    void testGetNormalPoint() {
        // ============ Equivalence Partitions Tests ==============

        // הגדרת שלוש נקודות לא קולינאריות ליצירת מישור
        Point p1 = new Point(0, 0, 1);
        Point p2 = new Point(1, 0, 0);
        Point p3 = new Point(0, 1, 0);

        // בניית מישור עם 3 נקודות
        Plane pl = new Plane(p1, p2, p3);

        // קבלת הנורמל מהנקודה p1
        Vector normal = pl.getNormal(p1);

        // TC01: אורך הנורמל צריך להיות בדיוק 1
        assertEquals(1, normal.length(), 0.00001, "Normal vector is not unit length");

        // TC02: הנורמל צריך להיות מאונך לווקטורים שעל המישור
        Vector v1 = p2.subtract(p1);
        Vector v2 = p3.subtract(p1);

        assertEquals(0, normal.dotProduct(v1), 0.00001, "Normal is not orthogonal to vector1");
        assertEquals(0, normal.dotProduct(v2), 0.00001, "Normal is not orthogonal to vector2");
    }

    /**
     * Test method for {@link geometries.Plane#getNormal()}.
     */
    @Test
    void testGetNormal() {
        // יוצרים מישור עם נקודה ונורמל
        Point q0 = new Point(0, 0, 1);
        Vector n = new Vector(0, 0, 1);
        Plane pl = new Plane(q0, n);

        // TC01: הנורמל שמוחזר אמור להיות זהה (מנורמל)
        assertEquals(n.normalize(), pl.getNormal(), "Wrong normal returned");

        // TC02: הנורמל באורך 1
        assertEquals(1, pl.getNormal().length(), 0.00001, "Normal is not unit length");
    }
}