/**
 * 
 */
package unittests;

import geometries.Cylinder;
import primitives.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for geometries.Cylinder class
* @author Ahuva Winkler
 */
class CylinderTests {

	/**
	 * Test method for {@link geometries.Cylinder#getNormal(primitives.Point)}.
	 */
	@Test
	void testGetNormal() {
		// ============ Equivalence Partitions Tests ==============

        Ray axis = new Ray(new Point(0, 0, 0), new Vector(0, 0, 1));
        Cylinder cyl = new Cylinder(axis, 2, 5);

        // TC01: נקודה על מעטפת הצד של הגליל
        Point p1 = new Point(0, 2, 2); // על הצד
        Vector expectedNormal1 = new Vector(0, 1, 0);
        Vector actualNormal1 = cyl.getNormal(p1);
        assertEquals(expectedNormal1, actualNormal1, "Bad normal to cylinder side");

        // TC02: נקודה על בסיס תחתון
        Point p2 = new Point(1, 1, 0); // על הבסיס התחתון
        Vector expectedNormal2 = new Vector(0, 0, -1);
        Vector actualNormal2 = cyl.getNormal(p2);
        assertEquals(expectedNormal2, actualNormal2, "Bad normal to bottom base");

        // TC03: נקודה על בסיס עליון
        Point p3 = new Point(1, 1, 5); // על הבסיס העליון
        Vector expectedNormal3 = new Vector(0, 0, 1);
        Vector actualNormal3 = cyl.getNormal(p3);
        assertEquals(expectedNormal3, actualNormal3, "Bad normal to top base");
    }
	
}
