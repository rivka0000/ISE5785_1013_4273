/**
 * 
 */
package unittests;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import primitives.Point;
import primitives.Vector;
/**
 * Unit tests for primitives.Point class
 * @author Ahuva Winkler  
 */
class PointTests {

	/**
	 * Test method for {@link primitives.Point#subtract(primitives.Point)}.
	 */
	@Test
	void testSubtract() {
		// ============ Equivalence Partitions Tests ==============

	    // TC01: חיסור תקין של נקודות
	    Point p1 = new Point(2, 3, 4);
	    Point p2 = new Point(1, 1, 1);
	    Vector expected = new Vector(1, 2, 3);
	    assertEquals(expected, p1.subtract(p2), "subtract() wrong result");

	    // =============== Boundary Values Tests ==================

	    // TC11: חיסור של נקודה מעצמה – אמור לזרוק חריגה
	    assertThrows(IllegalArgumentException.class,
	        () -> p1.subtract(p1),
	        "subtract() should throw exception when subtracting the same point");
	}

	/**
	 * Test method for {@link primitives.Point#add(primitives.Vector)}.
	 */
	@Test
	void testAdd() {
		Point p=new Point(1,2,3);
		Vector v= new Vector(1,-1,4);
		Point expected =new Point(2,1,7);
		assertEquals(expected,p.add(v),"add() wrong result");
	}

	/**
	 * Test method for {@link primitives.Point#distanceSquared(primitives.Point)}.
	 */
	@Test
	void testDistanceSquared() {
		Point p1 = new Point(1, 2, 3);
	    Point p2 = new Point(4, 6, 3); 
	    double expected = 3*3 + 4*4; 
	    assertEquals(expected, p1.distanceSquared(p2), 0.00001, "distanceSquared() wrong result");
	}

	/**
	 * Test method for {@link primitives.Point#distance(primitives.Point)}.
	 */
	@Test
	void testDistance() {
		 Point p1 = new Point(1, 2, 3);
		    Point p2 = new Point(4, 6, 3);
		    double expected = 5.0; // sqrt(25)
		    assertEquals(expected, p1.distance(p2), 0.00001, "distance() wrong result");
	}

}
