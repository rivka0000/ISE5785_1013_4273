/**
 * 
 */
package unittests;

import static org.junit.jupiter.api.Assertions.*;
import geometries.Tube;
import primitives.*;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for geometries.Tube class
 * @author Ahuva Winkler  
 */
class TubeTests {

	/**
	 * Test method for {@link geometries.Tube#getNormal(primitives.Point)}.
	 */
	@Test
	void testGetNormal() {
		 // Tube עם רדיוס 1 וציר לאורך ציר Z
        Ray axisRay = new Ray(new Point(0, 0, 0), new Vector(0, 0, 1));
        Tube tube = new Tube(axisRay, 1);

        // נקודה על המעטפת החיצונית של הצינור (במרכז Z = 5)
        Point point = new Point(0, 1, 5);

        // הנורמל צריך להיות וקטור מהמרכז לנקודה: (0, 1, 0)
        Vector expectedNormal = new Vector(0, 1, 0);

        assertEquals(expectedNormal, tube.getNormal(point), "Tube getNormal() returned wrong normal");
	}

}
