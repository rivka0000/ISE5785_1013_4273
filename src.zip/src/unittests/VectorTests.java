/**
 * 
 */
package unittests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import primitives.Point;
import primitives.Vector;
/**
 * Unit tests for primitives.Vector class
 * @author Ahuva Winkler  
 */
class VectorTests {

	/**
	 * Test method for {@link primitives.Vector#add(primitives.Vector)}.
	 */
	@Test
	void testAddVector() {
		Vector v1=new Vector(1,2,3);
		Vector v2=new Vector(-1,-2,-3);
		Vector expected=new Vector(0,0,0);
		
		assertThrows(IllegalArgumentException.class, () -> v1.add(v2), "Expected exception for zero vector");
		
	}
	
	/**
     * Test method for {@link primitives.Vector#subtract(primitives.Vector)}.
     */
    @Test
    void testSubtract() {
        // TC01: חיסור של שני וקטורים
        Vector v1 = new Vector(2, 3, 4);
        Vector v2 = new Vector(1, 1, 1);
        assertEquals(new Vector(1, 2, 3), v1.subtract(v2), "Wrong result from subtract()");
    }

	/**
	 * Test method for {@link primitives.Vector#scale(double)}.
	 */
	@Test
	void testScale() {
		Vector v=new Vector(1,2,3);
		assertEquals(new Vector(2, 4, 6), v.scale(2), "Wrong result for scale()");
		
		assertThrows(IllegalArgumentException.class, () -> v.scale(0), "Expected exception for scaling by zero");
	}

	/**
	 * Test method for {@link primitives.Vector#dotProduct(primitives.Vector)}.
	 */
	@Test
	void testDotProduct() {
		// TC01: מכפלה סקלרית רגילה
        Vector v1 = new Vector(1, 2, 3);
        Vector v2 = new Vector(4, -5, 6);
        double expected = 1*4 + 2*(-5) + 3*6; // 4 -10 +18 = 12
        assertEquals(expected, v1.dotProduct(v2), 0.00001, "Wrong dot product");

        // TC02: וקטורים מאונכים → מכפלה סקלרית = 0
        Vector v3 = new Vector(1, 0, 0);
        Vector v4 = new Vector(0, 1, 0);
        assertEquals(0, v3.dotProduct(v4), 0.00001, "Dot product of orthogonal vectors should be zero");
	}
	
	/**
     * Test method for {@link primitives.Vector#crossProduct(primitives.Vector)}.
     */
    @Test
    void testCrossProduct() {
        // TC01: תוצאה אורטוגונלית
        Vector v1 = new Vector(1, 0, 0);
        Vector v2 = new Vector(0, 1, 0);
        Vector cross = v1.crossProduct(v2);
        assertEquals(new Vector(0, 0, 1), cross, "Wrong cross product");

        // TC02: וקטורים מקבילים → אמור לזרוק חריגה
        assertThrows(IllegalArgumentException.class, () -> v1.crossProduct(new Vector(2, 0, 0)),
            "Expected exception for crossProduct of parallel vectors");
    }
    
    /**
     * Test method for {@link primitives.Vector#lengthSquared()}.
     */
    @Test
    void testLengthSquared() {
        Vector v = new Vector(1, 2, 2);
        assertEquals(9, v.lengthSquared(), 0.00001, "Wrong result from lengthSquared()");
    }
    
	/**
	 * Test method for {@link primitives.Vector#length()}.
	 */
	@Test
	void testLength() {
		 Vector v = new Vector(0, 3, 4);
	     assertEquals(5, v.length(), 0.00001, "Wrong result from length()");
	}

	/**
	 * Test method for {@link primitives.Vector#normalize()}.
	 */
	@Test
	void testNormalize() {
		Vector v = new Vector(0, 3, 4);
        Vector normalized = v.normalize();

        // TC01: אורך הנורמל צריך להיות 1
        assertEquals(1, normalized.length(), 0.00001, "Normalized vector is not unit length");

        // TC02: כיוון נשמר – מקבילים (cross product = 0)
        assertThrows(IllegalArgumentException.class,
            () -> v.crossProduct(normalized),
            "Normalized vector should be parallel to original vector");
	}

}
